package au.edu.utas.kit305.tutorialapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import au.edu.utas.kit305.tutorialapp.databinding.ActivityMainBinding
import au.edu.utas.kit305.tutorialapp.databinding.ActivitySummaryBinding
import au.edu.utas.kit305.tutorialapp.databinding.MyListItemBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

private lateinit var ui: ActivitySummaryBinding
class Summary : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivitySummaryBinding.inflate(layoutInflater)
        setContentView(ui.root)






            ui.lblMovieCount1.text = "${items.size} students"
            ui.myList1.adapter = MovieAdapter(movies = items)

            //vertical list
            ui.myList1.layoutManager = LinearLayoutManager(this)
            val db = Firebase.firestore
            /* val student = Student(
                   name = "Bruce Wayne",
                   studentID = 2001,
                   phone = +617283822
               )
               var moviesCollection = db.collection("studentList")
              moviesCollection
                   .add(student)
                   .addOnSuccessListener {
                       Log.d(FIREBASE_TAG, "Document created with id ${it.id}")
                       student.id = it.id
                   }
                   .addOnFailureListener {
                       Log.e(FIREBASE_TAG, "Error writing document", it)
                   }*/
            //get all movies


            var moviesCollection = db.collection("studentList")
            moviesCollection
                .get()
                .addOnSuccessListener { result ->
                    Log.d(FIREBASE_TAG, "--- all movies ---")
                    for (document in result) {


                        //Log.d(FIREBASE_TAG, document.toString())
                        val movie = document.toObject<Student>()
                        movie.id = document.id
                        Log.d(FIREBASE_TAG, movie.toString())





                    }

                }

ui.buttonBack.setOnClickListener(){
    finish()
}

        }

        inner class MovieHolder(var ui: MyListItemBinding) : RecyclerView.ViewHolder(ui.root) {}

        inner class MovieAdapter(private val movies: MutableList<Student>) :
            RecyclerView.Adapter<MovieHolder>() {


            override fun onCreateViewHolder(
                parent: ViewGroup,
                viewType: Int
            ): Summary.MovieHolder {
                val ui = MyListItemBinding.inflate(
                    layoutInflater,
                    parent,
                    false
                )   //inflate a new row from the my_list_item.xml
                return MovieHolder(ui)                                                            //wrap it in a ViewHolder
            }


            override fun getItemCount(): Int {
                return movies.size
            }

            override fun onBindViewHolder(holder: MovieHolder, position: Int) {
                val movie = movies[position]
                if(movie.grades?.isEmpty() == false) {
                    var weekGrade = ""
                    val week1 = movie.grades!![0].toString().toInt()
                    if (week1 > 0) {
                        weekGrade = "HD"
                    }
                    if (week1 < 100) {
                        weekGrade = "NN"
                    }
                    holder.ui.gradeWeek.text= "Week 1 Grade:$weekGrade"
                }

                if(movie.grades?.isEmpty() == false) {
                    var weekGrade1 = ""
                    val week2 = movie.grades!![1].toString().toInt()
                    if (week2 == 50) {
                        weekGrade1 = "PP"
                    }
                    if (week2 ==100) {
                        weekGrade1 = "HD"
                    }
                    if(week2==0){
                        weekGrade1="NN"
                    }
                    holder.ui.gradeWeek2.text= "Week 2 Grade:$weekGrade1"
                }



                val name= movie.name
                val ID=movie.studentID.toString()
                holder.ui.txtName.text = "Name: $name"
                holder.ui.txtYear.text = "StudentID: $ID \n  Click to read more about the student"

                holder.ui.root.setOnClickListener {
                    var i = Intent(holder.ui.root.context, studentSummary::class.java)
                    i.putExtra(MOVIE_INDEX, position)
                    startActivity(i)
                }
            }

        }
}


