package au.edu.utas.kit305.tutorialapp

data class Student (
    var id : String? = null,

    var name : String? = null,
    var studentID : Int? = null,
    var phone: Long? = null,
    var grades:MutableList<Int>? = mutableListOf<Int>(),
var photoURL:String? =null

)
