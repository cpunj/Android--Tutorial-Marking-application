package au.edu.utas.kit305.tutorialapp

import android.R
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import au.edu.utas.kit305.tutorialapp.databinding.ActivityMovieDetailsBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class StudentDetails : AppCompatActivity() {

    private lateinit var ui : ActivityMovieDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        var checkedItems: MutableList<String> = mutableListOf()

        var mySpinnerItem = arrayOf("A", "B", "C", "D", "E")

        super.onCreate(savedInstanceState)

        ui = ActivityMovieDetailsBinding.inflate(layoutInflater)
        setContentView(ui.root)


        ui.mySpin.adapter = ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            mySpinnerItem
        )

        val movieID = intent.getIntExtra(MOVIE_INDEX, -1)
        var movieObject = items[movieID]
ui.txtTitle.setText(movieObject.name)
        ui.txtDuration.setText(movieObject.phone.toString())
        ui.txtYear.setText(movieObject.studentID.toString())

        if(movieObject.grades?.isEmpty()==false){
            val week1 = movieObject.grades!![0].toString().toInt()
            if(week1 ==100) {
                ui.presentStu!!.isChecked = true
            }
            else{
                ui.presentStu!!.isChecked=false
            }
        }
        if(movieObject.grades?.isEmpty()==false){
            val week7 = movieObject.grades!![6].toString().toInt()
            if(week7 ==100) {
                ui.presentStu3!!.isChecked = true
            }
            else{
                ui.presentStu3!!.isChecked=false
            }
        }
        if(movieObject.grades?.isEmpty()==false){
            val week2=movieObject.grades!![1].toString().toInt()
            if(week2 ==50){
                ui.taskOne!!.isChecked= true
            }
            if(week2 ==100){
                ui.taskOne!!.isChecked = true
                ui.taskTwo!!.isChecked = true
            }
        }

        if(movieObject.grades?.isEmpty()==false) {
            val week3 = movieObject.grades!![2].toString().toInt()
            ui.marksField.setText(week3.toString())
        }
        if(movieObject.grades?.isEmpty()==false){
            val week4 = movieObject.grades!![3].toString().toInt()
            if(week4 ==100) {
                ui.presentStu2!!.isChecked = true
            }
            else{
                ui.presentStu2!!.isChecked=false
            }
        }

        if(movieObject.grades?.isEmpty()==false){
            val week5=movieObject.grades!![4].toString().toInt()
            if(week5==0){
                ui.taskThree!!.isChecked=false
            }
            if(week5 <50 && week5 >0){
                ui.taskThree!!.isChecked= true
            }
            if(week5 <100 && week5 >50){
                ui.taskThree!!.isChecked=true
                ui.taskFour!!.isChecked=true
            }
            if(week5 ==100){
                ui.taskThree!!.isChecked = true
                ui.taskFour!!.isChecked = true
                ui.taskFive!!.isChecked=true
            }
        }
        if(movieObject.grades?.isEmpty()==false) {
            val week6 = movieObject.grades!![5].toString().toInt()
            ui.marksField2.setText(week6.toString())
        }
       /* if(movieObject.grades!![1]== 100){
            ui.taskOne!!.isChecked=true
            ui.taskTwo!!.isChecked=true
        }

        if(movieObject.grades!![1]== 50){
            ui.taskOne!!.isChecked=true

        }
        if(movieObject.grades!![1]== 0){
            ui.taskOne!!.isChecked=false
            ui.taskTwo!!.isChecked=false

        }*/

        val builder = AlertDialog.Builder(this@StudentDetails)
        //TODO: read in movie details and display on this screen
        ui.btnSave.setOnClickListener {
            //get the user input


            val db = Firebase.firestore
            movieObject.name = ui.txtTitle.text.toString()
            movieObject.studentID =
                ui.txtYear.text.toString().toInt() //good code would check this is really an int
            movieObject.phone = ui.txtDuration.text.toString()
                .toLong() //good code would check this is really a float


            var moviesCollection = db.collection("studentList")
            //update the database
            moviesCollection.document(movieObject.id!!)
                .set(movieObject)
                .addOnSuccessListener {
                    Log.d(FIREBASE_TAG, "Successfully updated movie ${movieObject?.id}")
                    //return to the list
                    finish()
                }
        }
        ui.addMarks.setOnClickListener {
            if (ui.presentStu.isChecked == true) {
                Log.d(FIREBASE_TAG, "Successfully added grade ${movieObject?.id}")

                movieObject.grades?.add(0, 100)
                Toast.makeText(applicationContext, "Added 100 marks for week 1.Please click save", Toast.LENGTH_LONG)
                    .show()



            } else if (ui.presentStu.isChecked == false) {
                movieObject.grades?.add(0, 0)
                Toast.makeText(applicationContext, "Added 0 marks for week 1.Please click save", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskOne.isChecked == true) {
                movieObject.grades?.add(1, 50)
                Toast.makeText(applicationContext, "Added 50 marks for week 2", Toast.LENGTH_LONG)
                    .show()
            } else if (ui.taskTwo.isChecked == true) {
                movieObject.grades?.add(1, 50)
                Toast.makeText(applicationContext, "Added 50 marks for week 2. please click save", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskOne.isChecked == true && ui.taskTwo.isChecked == true) {
                movieObject.grades?.add(1, 100)
                Toast.makeText(applicationContext, "Added 100 marks for week 2.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskOne.isChecked == false && ui.taskTwo.isChecked == false) {
                movieObject.grades?.add(1, 0)
                Toast.makeText(applicationContext, "Added 0 marks for week 2.Plase click save.", Toast.LENGTH_LONG)
                    .show()
            }



            if (ui.marksField.length() != 0) {

                var marks = ui.marksField.text.toString().toInt()
                movieObject.grades?.add(2, marks)
                Toast.makeText(applicationContext,"Added:$marks for week 3.Please click save.",Toast.LENGTH_LONG).show()


            } else {

                val marks1 = 0
                movieObject.grades?.add(2, marks1)
            }


            if (ui.presentStu2.isChecked == true) {
                Log.d(FIREBASE_TAG, "Successfully added grade ${movieObject?.id}")

                movieObject.grades?.add(3, 100)
                Toast.makeText(applicationContext, "Added 100 marks for week 4.Please click save.", Toast.LENGTH_LONG)
                    .show()


            } else if (ui.presentStu2.isChecked == false) {
                movieObject.grades?.add(3, 0)
                Toast.makeText(applicationContext, "Added 0 marks for week 4.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }

            if (ui.taskThree.isChecked == true) {
                movieObject.grades?.add(4, 33)
                Toast.makeText(applicationContext, "Added 50 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            } else if (ui.taskFour.isChecked == true) {
                movieObject.grades?.add(4, 33)
                Toast.makeText(applicationContext, "Added 50 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }
            else if(ui.taskFive.isChecked == true){
                movieObject.grades?.add(4, 33)
                Toast.makeText(applicationContext, "Added 50 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskThree.isChecked == true && ui.taskFour.isChecked == true) {
                movieObject.grades?.add(4, 66)
                Toast.makeText(applicationContext, "Added 66 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskThree.isChecked == true && ui.taskFive.isChecked == true) {
                movieObject.grades?.add(4, 66)
                Toast.makeText(applicationContext, "Added 66 marks for week 5.Please click save", Toast.LENGTH_LONG)
                    .show()
            }

            if (ui.taskFour.isChecked == true && ui.taskFive.isChecked == true) {
                movieObject.grades?.add(4, 66)
                Toast.makeText(applicationContext, "Added 66 marks for week 5.Please click save", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskThree.isChecked == true && ui.taskFour.isChecked == true && ui.taskFive.isChecked== true) {
                movieObject.grades?.add(4, 100)
                Toast.makeText(applicationContext, "Added 100 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }
            if (ui.taskThree.isChecked == false && ui.taskFour.isChecked == false && ui.taskFive.isChecked==false) {
                movieObject.grades?.add(4, 0)
                Toast.makeText(applicationContext, "Added 0 marks for week 5.Please click save.", Toast.LENGTH_LONG)
                    .show()
            }

            if (ui.marksField2.length() != 0) {

                var marks1 = ui.marksField2.text.toString().toInt()
                movieObject.grades?.add(5, marks1)
                Toast.makeText(applicationContext,"Added:$marks1 for week 6.Please click save.",Toast.LENGTH_LONG).show()


            } else {

                val marks1 = 0
                movieObject.grades?.add(5, marks1)
            }




                    ui.mySpin.adapter = ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                mySpinnerItem
            )

            if (ui.presentStu3.isChecked == true) {
                Log.d(FIREBASE_TAG, "Successfully added grade ${movieObject?.id}")

                movieObject.grades?.add(6, 100)
                Toast.makeText(applicationContext, "Added 100 marks for week 7.Please click save", Toast.LENGTH_LONG)
                    .show()



            } else if (ui.presentStu3.isChecked == false) {
                movieObject.grades?.add(6, 0)
                Toast.makeText(applicationContext, "Added 0 marks for week 7", Toast.LENGTH_LONG)
                    .show()
            }

                    // to close the onItemSeleced

                    ui.mySpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View,
                    position: Int,
                    id: Long
                ) {

                }



                override fun onNothingSelected(parent: AdapterView<*>?) {

                    //
                }
            }// to close the onItemSelected
            /*  var marks= ui.marksField.text.toString().toInt()

              if(ui.marksField.length() >0){
                  movieObject.grades?.add(2,marks)
              }
              else {
                  movieObject.grades?.add(2, 0)
              }*/


        }
        ui.btnDelete.setOnClickListener {
            val db = Firebase.firestore
            var moviesCollection = db.collection("studentList")
            moviesCollection.document(movieObject.id!!).delete().addOnSuccessListener {
                items.removeAt(movieID)
                Log.d(FIREBASE_TAG, "Successfully deleted movie ${movieObject?.id}")
                finish()
            }

        }

        }
    }

