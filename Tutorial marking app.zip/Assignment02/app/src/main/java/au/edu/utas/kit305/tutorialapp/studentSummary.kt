package au.edu.utas.kit305.tutorialapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import au.edu.utas.kit305.tutorialapp.databinding.ActivityStudentSummaryBinding

class studentSummary : AppCompatActivity() {
    private lateinit var ui : ActivityStudentSummaryBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_summary)
        ui = ActivityStudentSummaryBinding.inflate(layoutInflater)
        setContentView(ui.root)

        val movieID = intent.getIntExtra(MOVIE_INDEX, -1)
        var movieObject = items[movieID]
        if(movieObject.grades?.isEmpty() == false) {
            var weekGrade = ""
            val week1 = movieObject.grades!![0].toString().toInt()
            if (week1 > 0) {
                weekGrade = "HD"
            }
            if (week1 < 100) {
                weekGrade = "NN"
            }
            ui.textView26.setText(weekGrade)
        }

        if(movieObject.grades?.isEmpty() == false) {
            var weekGrade1 = ""
            val week2 = movieObject.grades!![1].toString().toInt()
            if (week2 == 50) {
                weekGrade1 = "PP/ $week2"
            }
            if (week2 ==100) {
                weekGrade1 = "HD/ $week2"
            }
            if(week2==0){
                weekGrade1="NN / $week2"
            }
            ui.textView27.setText(weekGrade1)
        }

        if(movieObject.grades?.isEmpty() == false) {

            val week3 = movieObject.grades!![2].toString().toInt()

            ui.textView28.setText("$week3 %")
        }
            if(movieObject.grades?.isEmpty() == false) {
                var weekGrade4 = ""
                val week4 = movieObject.grades!![3].toString().toInt()
                if (week4 > 0) {
                    weekGrade4 = "HD"
                }
                if (week4 < 100) {
                    weekGrade4 = "NN"
                }
                ui.textView29.setText(weekGrade4)
            }

        if(movieObject.grades?.isEmpty() == false) {

            val week5 = movieObject.grades!![4].toString().toInt()
if(week5 == 33){
    ui.textView30.setText("NN /$week5")
}
            if(week5==66){
                ui.textView30.setText("CR /$week5")
            }
            if(week5==100){
                ui.textView30.setText("HD /$week5")
            }

        }
        if(movieObject.grades?.isEmpty() == false) {

            val week6 = movieObject.grades!![5].toString().toInt()

            ui.textView31.setText("$week6 %")
        }
        if(movieObject.grades?.isEmpty() == false) {

            var weekGrade7 = ""
            val week7 = movieObject.grades!![6].toString().toInt()
            if (week7 > 0) {
                weekGrade7 = "HD"
            }
            if (week7 < 100) {
                weekGrade7 = "NN"
            }
            ui.textView32.setText(weekGrade7)
        }


        ui.btnSend2.setOnClickListener {

            var sendIntent = Intent().apply {
                val name= movieObject.name.toString()
                val phone=movieObject.phone.toString()
                val id= movieObject.studentID.toString()


                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT,"Name: $name"+ "\n" + "Phone:$phone" + "\n" + "$id" +  "\n" + "Week 1: "+
                "\t" + ui.textView26.text.toString() +  "\n" + "Week 2: "+
                        "\t" + ui.textView27.text.toString() +  "\n" + "Week 3: "+
                        "\t" + ui.textView28.text.toString() +  "\n" + "Week 4: "+
                        "\t" + ui.textView29.text.toString() +  "\n" + "Week 5: "+
                        "\t" + ui.textView30.text.toString()+  "\n" + "Week 6: "+
                        "\t" + ui.textView31.text.toString()  +  "\n" + "Week 7: "+
                        "\t" + ui.textView32.text.toString()+ "\n"+ "Total marks:" + "\t" + ui.textView34.text.toString())


                type = "text/plain"
            }
            startActivity(Intent.createChooser(sendIntent, "Share via..."))
        }
        if(movieObject.grades?.isEmpty() == false) {

            val week0 = movieObject.grades!![0].toString().toInt()
            val week01 = movieObject.grades!![1].toString().toInt()
            val week001 = movieObject.grades!![2].toString().toInt()
            val week0001 = movieObject.grades!![3].toString().toInt()
            val week000001 = movieObject.grades!![4].toString().toInt()
            val week00001 = movieObject.grades!![5].toString().toInt()
            val week02= movieObject.grades!![6].toString().toInt()

            val weektotal= ((week0+week01+week000001+week00001+week001+week0001+week02)*100)/700
            val gradetotal1= "$weektotal %"
            ui.textView34.setText(gradetotal1)
        }

        //share in
        if (intent?.action == Intent.ACTION_SEND && intent?.type != null)
        {
            if (intent?.type == "text/plain")
            {
                var sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""

                //do something with sharedText
                ui.lblSharedText.text = "Recieved: $sharedText"




            }
        }
        ui.textView23.setText(movieObject.name)
        ui.textView24.setText(movieObject.phone.toString())
        ui.textView25.setText(movieObject.studentID.toString())

    }
}